# ذاكرتي (Zakirati)

تطبيق جوال شخصي ذكي لحفظ المعلومات والمستندات والصور والتذكيرات، مع قدرات الذكاء الاصطناعي للتنظيم والبحث والاسترجاع.

## الميزات الحالية

- إضافة ذكريات نصية وصور ومستندات وتذكيرات
- تحليل تلقائي بالمحتوى (ملخص + وسوم + تصنيف) – يعمل حالياً بوضع تجريبي (Mock)
- بحث بالكتابة والصوت (Speech-to-Text)
- تخزين محلي دائم باستخدام Hive
- واجهة عربية كاملة مع دعم RTL
- الوضع الليلي/النهاري

## كيفية التشغيل

### المتطلبات
- Flutter SDK 3.16 أو أحدث
- Android Studio أو VS Code مع إضافة Flutter
- جهاز أو محاكي Android / iOS

### الخطوات

1. فك ضغط الملف
2. افتح المجلد في VS Code أو Android Studio
3. نفّذ الأوامر التالية:

```bash
flutter pub get
flutter run
```

### لربط الذكاء الاصطناعي الحقيقي

افتح الملف:
`lib/services/ai_service.dart`

ثم غيّر:
```dart
provider = 'openai'; // أو 'gemini'
apiKey = 'YOUR_API_KEY_HERE';
```

أو أضف شاشة إعدادات لحفظ المفتاح بشكل آمن.

## هيكل المشروع

```
lib/
├── main.dart
├── models/
│   └── memory_item.dart
├── services/
│   ├── storage_service.dart
│   └── ai_service.dart
├── screens/
│   ├── home_screen.dart
│   ├── add_memory_screen.dart
│   ├── memory_detail_screen.dart
│   ├── search_screen.dart
│   └── reminders_screen.dart
└── utils/
    └── app_theme.dart
```

## ملاحظات مهمة

- التطبيق يعمل بالكامل بدون إنترنت (ما عدا استدعاءات AI الحقيقية).
- الصور والملفات تُحفظ مساراتها محلياً.
- للإنتاج: أضف صلاحيات الكاميرا والمايكروفون والتخزين في `AndroidManifest.xml` و `Info.plist`.
- يُفضّل إضافة `google_mlkit_text_recognition` لـ OCR الحقيقي.

## التطوير المستقبلي المقترح

- [ ] Embeddings + بحث دلالي حقيقي
- [ ] OCR للمستندات والصور
- [ ] مزامنة مشفرة (Firebase / Supabase)
- [ ] إشعارات محلية للتذكيرات
- [ ] نماذج AI محلية (Ollama / MediaPipe)
- [ ] تصدير واستيراد البيانات

---

صُنع بحب لتطبيق **ذاكرتي**
