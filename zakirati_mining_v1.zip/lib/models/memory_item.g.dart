// GENERATED CODE - DO NOT MODIFY BY HAND
// هذا الملف يُنشأ عادةً بواسطة build_runner
// قمت بإنشائه يدويًا ليعمل المشروع فورًا

part of 'memory_item.dart';

class MemoryItemAdapter extends TypeAdapter<MemoryItem> {
  @override
  final int typeId = 0;

  @override
  MemoryItem read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MemoryItem(
      id: fields[0] as String,
      title: fields[1] as String,
      content: fields[2] as String,
      createdAt: fields[3] as DateTime,
      updatedAt: fields[4] as DateTime,
      type: fields[5] as String,
      tags: (fields[6] as List).cast<String>(),
      imagePath: fields[7] as String?,
      filePath: fields[8] as String?,
      audioPath: fields[9] as String?,
      reminderDate: fields[10] as DateTime?,
      isReminderDone: fields[11] as bool,
      summary: fields[12] as String?,
      entities: (fields[13] as List?)?.cast<String>() ?? [],
      category: fields[14] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, MemoryItem obj) {
    writer
      ..writeByte(15)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.content)
      ..writeByte(3)
      ..write(obj.createdAt)
      ..writeByte(4)
      ..write(obj.updatedAt)
      ..writeByte(5)
      ..write(obj.type)
      ..writeByte(6)
      ..write(obj.tags)
      ..writeByte(7)
      ..write(obj.imagePath)
      ..writeByte(8)
      ..write(obj.filePath)
      ..writeByte(9)
      ..write(obj.audioPath)
      ..writeByte(10)
      ..write(obj.reminderDate)
      ..writeByte(11)
      ..write(obj.isReminderDone)
      ..writeByte(12)
      ..write(obj.summary)
      ..writeByte(13)
      ..write(obj.entities)
      ..writeByte(14)
      ..write(obj.category);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MemoryItemAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
