class MiningDevice {
  final String id;
  final String name;
  final String walletAddress;
  final String coin;
  final bool active;
  final double hashrate;
  final double earned;
  final DateTime lastSeen;

  const MiningDevice({
    required this.id,
    required this.name,
    required this.walletAddress,
    required this.coin,
    required this.active,
    required this.hashrate,
    required this.earned,
    required this.lastSeen,
  });

  MiningDevice copyWith({
    String? name,
    String? walletAddress,
    String? coin,
    bool? active,
    double? hashrate,
    double? earned,
    DateTime? lastSeen,
  }) => MiningDevice(
        id: id,
        name: name ?? this.name,
        walletAddress: walletAddress ?? this.walletAddress,
        coin: coin ?? this.coin,
        active: active ?? this.active,
        hashrate: hashrate ?? this.hashrate,
        earned: earned ?? this.earned,
        lastSeen: lastSeen ?? this.lastSeen,
      );
}
