import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/storage_service.dart';
import '../models/memory_item.dart';
import '../utils/app_theme.dart';
import 'add_memory_screen.dart';
import 'memory_detail_screen.dart';
import 'search_screen.dart';
import 'reminders_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: const [
          _MemoriesTab(),
          SearchScreen(),
          RemindersScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => setState(() => _currentIndex = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'ذكرياتي',
          ),
          NavigationDestination(
            icon: Icon(Icons.search_outlined),
            selectedIcon: Icon(Icons.search_rounded),
            label: 'بحث',
          ),
          NavigationDestination(
            icon: Icon(Icons.notifications_outlined),
            selectedIcon: Icon(Icons.notifications_rounded),
            label: 'تذكيرات',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddMemoryScreen()),
          );
        },
        icon: const Icon(Icons.add_rounded),
        label: const Text('إضافة'),
      ),
    );
  }
}

class _MemoriesTab extends StatelessWidget {
  const _MemoriesTab();

  @override
  Widget build(BuildContext context) {
    final storage = context.watch<StorageService>();
    final memories = storage.allMemories;

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          floating: true,
          title: const Text('ذاكرتي'),
          actions: [
            IconButton(
              icon: const Icon(Icons.info_outline),
              onPressed: () => _showAbout(context),
            ),
          ],
        ),
        if (memories.isEmpty)
          SliverFillRemaining(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.memory_rounded, size: 80, color: Colors.grey.shade300),
                  const SizedBox(height: 16),
                  Text(
                    'لا توجد ذكريات بعد',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: Colors.grey.shade500,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'اضغط على زر "إضافة" لحفظ أول ذكرى',
                    style: TextStyle(color: Colors.grey.shade400),
                  ),
                ],
              ),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
            sliver: SoftGrid(
              memories: memories,
            ),
          ),
      ],
    );
  }

  void _showAbout(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('عن ذاكرتي'),
        content: const Text(
          'تطبيق شخصي ذكي لحفظ المعلومات والمستندات والصور والتذكيرات، '
          'مع قدرات الذكاء الاصطناعي للتنظيم والبحث والاسترجاع.\n\n'
          'الإصدار 1.0.0',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }
}

class SoftGrid extends StatelessWidget {
  final List<MemoryItem> memories;
  const SoftGrid({super.key, required this.memories});

  @override
  Widget build(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final item = memories[index];
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _MemoryCard(item: item),
          );
        },
        childCount: memories.length,
      ),
    );
  }
}

class _MemoryCard extends StatelessWidget {
  final MemoryItem item;
  const _MemoryCard({required this.item});

  IconData get _icon {
    switch (item.type) {
      case 'image':
        return Icons.image_rounded;
      case 'document':
        return Icons.description_rounded;
      case 'voice':
        return Icons.mic_rounded;
      case 'reminder':
        return Icons.alarm_rounded;
      default:
        return Icons.notes_rounded;
    }
  }

  Color get _color {
    switch (item.type) {
      case 'image':
        return Colors.teal;
      case 'document':
        return Colors.orange;
      case 'voice':
        return Colors.purple;
      case 'reminder':
        return AppTheme.accent;
      default:
        return AppTheme.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('d MMM yyyy • HH:mm', 'ar');

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => MemoryDetailScreen(item: item),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: _color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(_icon, color: _color, size: 26),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title.isEmpty ? 'بدون عنوان' : item.title,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item.summary ?? item.content,
                      style: TextStyle(
                        color: Colors.grey.shade600,
                        fontSize: 13.5,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Text(
                          dateFormat.format(item.updatedAt),
                          style: TextStyle(
                            color: Colors.grey.shade400,
                            fontSize: 12,
                          ),
                        ),
                        if (item.category != null) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              item.category!,
                              style: const TextStyle(
                                color: AppTheme.primary,
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
