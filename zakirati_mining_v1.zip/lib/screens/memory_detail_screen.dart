import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'dart:io';

import '../models/memory_item.dart';
import '../services/storage_service.dart';
import '../utils/app_theme.dart';
import 'add_memory_screen.dart';

class MemoryDetailScreen extends StatelessWidget {
  final MemoryItem item;
  const MemoryDetailScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('EEEE d MMMM yyyy • HH:mm', 'ar');

    return Scaffold(
      appBar: AppBar(
        title: const Text('تفاصيل الذكرى'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_rounded),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AddMemoryScreen(existing: item),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: () => _confirmDelete(context),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // العنوان
            Text(
              item.title.isEmpty ? 'بدون عنوان' : item.title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 8),

            // التاريخ
            Text(
              dateFormat.format(item.createdAt),
              style: TextStyle(color: Colors.grey.shade500, fontSize: 13),
            ),
            const SizedBox(height: 20),

            // الصورة
            if (item.imagePath != null) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.file(
                  File(item.imagePath!),
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 20),
            ],

            // الملف
            if (item.filePath != null) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.description, color: Colors.orange, size: 32),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        item.filePath!.split('/').last,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],

            // التذكير
            if (item.reminderDate != null) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.alarm, color: AppTheme.accent),
                    const SizedBox(width: 12),
                    Text(
                      'تذكير: ${DateFormat('d MMM yyyy • HH:mm', 'ar').format(item.reminderDate!)}',
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],

            // الملخص من AI
            if (item.summary != null && item.summary!.isNotEmpty) ...[
              Text(
                'الملخص',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primary,
                    ),
              ),
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(item.summary!),
              ),
              const SizedBox(height: 20),
            ],

            // المحتوى
            if (item.content.isNotEmpty) ...[
              Text(
                'المحتوى',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                item.content,
                style: const TextStyle(height: 1.6, fontSize: 15.5),
              ),
              const SizedBox(height: 20),
            ],

            // التصنيف والوسوم
            if (item.category != null || item.tags.isNotEmpty) ...[
              Text(
                'التصنيف والوسوم',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (item.category != null)
                    Chip(
                      label: Text(item.category!),
                      backgroundColor: AppTheme.primary.withOpacity(0.15),
                      labelStyle: const TextStyle(
                        color: AppTheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ...item.tags.map(
                    (t) => Chip(
                      label: Text(t),
                      backgroundColor: Colors.grey.shade100,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف الذكرى؟'),
        content: const Text('لا يمكن التراجع عن هذا الإجراء.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () async {
              await context.read<StorageService>().deleteMemory(item.id);
              if (context.mounted) {
                Navigator.pop(context); // إغلاق الحوار
                Navigator.pop(context); // العودة للشاشة السابقة
              }
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }
}
