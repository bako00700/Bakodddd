import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/mining_service.dart';

class MiningScreen extends StatefulWidget {
  const MiningScreen({super.key});

  @override
  State<MiningScreen> createState() => _MiningScreenState();
}

class _MiningScreenState extends State<MiningScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<MiningService>().init());
  }

  @override
  Widget build(BuildContext context) {
    final mining = context.watch<MiningService>();
    return Scaffold(
      appBar: AppBar(title: const Text('التعدين والأجهزة')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('المحفظة الرئيسية', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(mining.walletAddress.isEmpty ? 'لم تتم إضافة محفظة' : mining.walletAddress,
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: () => _walletDialog(context, mining),
                  icon: const Icon(Icons.account_balance_wallet_outlined),
                  label: const Text('إعداد المحفظة'),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _stat('الأجهزة', '${mining.activeDevices}/${mining.devices.length}', Icons.devices)),
            const SizedBox(width: 8),
            Expanded(child: _stat('Hashrate', '${mining.totalHashrate.toStringAsFixed(2)} H/s', Icons.speed)),
            const SizedBox(width: 8),
            Expanded(child: _stat('الإجمالي', mining.totalEarned.toStringAsFixed(6), Icons.paid)),
          ]),
          const SizedBox(height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('الأجهزة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            IconButton(onPressed: () => _addDevice(context, mining), icon: const Icon(Icons.add_circle_outline)),
          ]),
          if (mining.devices.isEmpty)
            const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('أضف أول هاتف إلى لوحة التعدين.')))
          else
            ...mining.devices.map((d) => Card(
              child: ListTile(
                leading: CircleAvatar(child: Icon(d.active ? Icons.bolt : Icons.phone_android)),
                title: Text(d.name),
                subtitle: Text('${d.coin} • ${d.hashrate.toStringAsFixed(2)} H/s\nالعائد: ${d.earned.toStringAsFixed(6)}'),
                isThreeLine: true,
                trailing: Switch(value: d.active, onChanged: (_) => mining.toggleDevice(d.id)),
              ),
            )),
          const SizedBox(height: 12),
          const Text('تنبيه: الشاشة الحالية هي طبقة إدارة/محاكاة فقط. لا يتم تشغيل تعدين حقيقي على الهاتف حتى يتم ربط خوارزمية وMining Pool متوافقين.',
              style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  Widget _stat(String title, String value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(10), child: Column(children: [Icon(icon, size: 22), const SizedBox(height: 5), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)), Text(title, style: const TextStyle(fontSize: 11))])),
  );

  Future<void> _walletDialog(BuildContext context, MiningService mining) async {
    final controller = TextEditingController(text: mining.walletAddress);
    var coin = mining.coin;
    await showDialog(context: context, builder: (_) => StatefulBuilder(builder: (context, setState) => AlertDialog(
      title: const Text('المحفظة'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(value: coin, items: const [DropdownMenuItem(value: 'BTC', child: Text('Bitcoin')), DropdownMenuItem(value: 'LTC', child: Text('Litecoin')), DropdownMenuItem(value: 'DOGE', child: Text('Dogecoin'))], onChanged: (v) => setState(() => coin = v ?? coin)),
        const SizedBox(height: 12),
        TextField(controller: controller, maxLines: 3, decoration: const InputDecoration(labelText: 'عنوان المحفظة', border: OutlineInputBorder())),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')), FilledButton(onPressed: () async { await mining.setWallet(controller.text, coin); if (context.mounted) Navigator.pop(context); }, child: const Text('حفظ'))],
    )));
  }

  Future<void> _addDevice(BuildContext context, MiningService mining) async {
    final controller = TextEditingController(text: 'هاتف ${mining.devices.length + 1}');
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('إضافة جهاز'),
      content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(labelText: 'اسم الجهاز')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')), FilledButton(onPressed: () { if (controller.text.trim().isNotEmpty) mining.addDevice(controller.text.trim()); Navigator.pop(context); }, child: const Text('إضافة'))],
    ));
  }
}
