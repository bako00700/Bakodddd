import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../services/storage_service.dart';
import '../models/memory_item.dart';
import '../utils/app_theme.dart';
import 'memory_detail_screen.dart';
import 'add_memory_screen.dart';

class RemindersScreen extends StatelessWidget {
  const RemindersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final storage = context.watch<StorageService>();
    final reminders = storage.reminders;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          const SliverAppBar(
            floating: true,
            title: Text('التذكيرات'),
          ),
          if (reminders.isEmpty)
            SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.notifications_none_rounded,
                        size: 72, color: Colors.grey.shade300),
                    const SizedBox(height: 16),
                    Text(
                      'لا توجد تذكيرات حالياً',
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AddMemoryScreen(),
                          ),
                        );
                      },
                      icon: const Icon(Icons.add_alarm_rounded),
                      label: const Text('إضافة تذكير'),
                    ),
                  ],
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final item = reminders[index];
                    return _ReminderTile(item: item);
                  },
                  childCount: reminders.length,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ReminderTile extends StatelessWidget {
  final MemoryItem item;
  const _ReminderTile({required this.item});

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('EEEE d MMM • HH:mm', 'ar');
    final isPast = item.reminderDate != null &&
        item.reminderDate!.isBefore(DateTime.now());

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: isPast
                ? Colors.grey.withOpacity(0.15)
                : AppTheme.accent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            Icons.alarm_rounded,
            color: isPast ? Colors.grey : AppTheme.accent,
          ),
        ),
        title: Text(
          item.title.isEmpty ? 'تذكير' : item.title,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            decoration: item.isReminderDone ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (item.reminderDate != null)
              Text(
                dateFormat.format(item.reminderDate!),
                style: TextStyle(
                  color: isPast ? Colors.grey : AppTheme.accent,
                  fontWeight: FontWeight.w500,
                  fontSize: 13,
                ),
              ),
            if (item.content.isNotEmpty)
              Text(
                item.content,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
              ),
          ],
        ),
        trailing: Checkbox(
          value: item.isReminderDone,
          activeColor: AppTheme.primary,
          onChanged: (v) async {
            final updated = item.copyWith(isReminderDone: v ?? false);
            await context.read<StorageService>().updateMemory(updated);
          },
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => MemoryDetailScreen(item: item),
            ),
          );
        },
      ),
    );
  }
}
