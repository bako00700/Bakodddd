import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/mining_device.dart';

/// إدارة حالة أجهزة التعدين والمحفظة.
/// هذه الطبقة لا تنفذ تعدينًا حقيقيًا؛ وهي جاهزة لربط Mining Pool/API لاحقًا.
class MiningService extends ChangeNotifier {
  final List<MiningDevice> _devices = [];
  Timer? _timer;
  String _walletAddress = '';
  String _coin = 'BTC';
  double _totalEarned = 0;
  bool _connected = false;

  List<MiningDevice> get devices => List.unmodifiable(_devices);
  String get walletAddress => _walletAddress;
  String get coin => _coin;
  double get totalEarned => _totalEarned;
  bool get connected => _connected;
  double get totalHashrate => _devices.fold(0, (sum, d) => sum + d.hashrate);
  int get activeDevices => _devices.where((d) => d.active).length;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _walletAddress = prefs.getString('mining_wallet') ?? '';
    _coin = prefs.getString('mining_coin') ?? 'BTC';
    _totalEarned = prefs.getDouble('mining_earned') ?? 0;
    _connected = _walletAddress.isNotEmpty;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _refreshDemoState());
    notifyListeners();
  }

  Future<void> setWallet(String address, String coin) async {
    _walletAddress = address.trim();
    _coin = coin;
    _connected = _walletAddress.isNotEmpty;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('mining_wallet', _walletAddress);
    await prefs.setString('mining_coin', _coin);
    notifyListeners();
  }

  void addDevice(String name) {
    final now = DateTime.now();
    _devices.add(MiningDevice(
      id: now.microsecondsSinceEpoch.toString(),
      name: name,
      walletAddress: _walletAddress,
      coin: _coin,
      active: false,
      hashrate: 0,
      earned: 0,
      lastSeen: now,
    ));
    notifyListeners();
  }

  void toggleDevice(String id) {
    final index = _devices.indexWhere((d) => d.id == id);
    if (index < 0) return;
    final device = _devices[index];
    _devices[index] = device.copyWith(
      active: !device.active,
      hashrate: !device.active ? 0.0 : 0.0,
      lastSeen: DateTime.now(),
    );
    notifyListeners();
  }

  void _refreshDemoState() {
    // بيانات عرض فقط إلى حين ربط Pool حقيقي.
    for (var i = 0; i < _devices.length; i++) {
      final d = _devices[i];
      if (!d.active) continue;
      final rate = d.hashrate == 0 ? 1.0 : d.hashrate;
      final earned = d.earned + rate * 0.000001;
      _devices[i] = d.copyWith(
        hashrate: rate,
        earned: earned,
        lastSeen: DateTime.now(),
      );
      _totalEarned += rate * 0.000001;
    }
    notifyListeners();
  }

  Future<void> persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('mining_earned', _totalEarned);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
