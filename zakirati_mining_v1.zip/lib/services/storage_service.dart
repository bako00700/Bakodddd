import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/memory_item.dart';

class StorageService extends ChangeNotifier {
  final Box<MemoryItem> _box = Hive.box<MemoryItem>('memories');

  List<MemoryItem> get allMemories {
    final list = _box.values.toList();
    list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return list;
  }

  List<MemoryItem> get reminders {
    return allMemories
        .where((m) => m.type == 'reminder' && !m.isReminderDone)
        .toList()
      ..sort((a, b) => (a.reminderDate ?? DateTime.now())
          .compareTo(b.reminderDate ?? DateTime.now()));
  }

  List<String> get allCategories {
    final cats = allMemories
        .where((m) => m.category != null && m.category!.isNotEmpty)
        .map((m) => m.category!)
        .toSet()
        .toList();
    cats.sort();
    return cats;
  }

  List<String> get allTags {
    final tags = <String>{};
    for (var m in allMemories) {
      tags.addAll(m.tags);
    }
    return tags.toList()..sort();
  }

  Future<void> addMemory(MemoryItem item) async {
    await _box.put(item.id, item);
    notifyListeners();
  }

  Future<void> updateMemory(MemoryItem item) async {
    await _box.put(item.id, item);
    notifyListeners();
  }

  Future<void> deleteMemory(String id) async {
    await _box.delete(id);
    notifyListeners();
  }

  MemoryItem? getById(String id) => _box.get(id);

  List<MemoryItem> search(String query) {
    if (query.trim().isEmpty) return allMemories;
    final q = query.toLowerCase();
    return allMemories.where((m) {
      return m.title.toLowerCase().contains(q) ||
          m.content.toLowerCase().contains(q) ||
          (m.summary?.toLowerCase().contains(q) ?? false) ||
          m.tags.any((t) => t.toLowerCase().contains(q)) ||
          m.entities.any((e) => e.toLowerCase().contains(q)) ||
          (m.category?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  List<MemoryItem> filterByType(String type) {
    return allMemories.where((m) => m.type == type).toList();
  }

  List<MemoryItem> filterByCategory(String category) {
    return allMemories.where((m) => m.category == category).toList();
  }

  Future<void> clearAll() async {
    await _box.clear();
    notifyListeners();
  }
}
